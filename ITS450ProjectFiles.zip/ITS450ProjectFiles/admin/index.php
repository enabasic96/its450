<?php

// This is the adminstrative home page.
// This script is created in Chapter 11.

// Require the configuration before any PHP code as configuration controls error reporting.
require('../includes/config.inc.php');


include('./includes/header.html');
// The header file begins the session.

?>

<!--
<ul>
<li><a href="add_specific_coffees.php">Add Video Games</a></li>
<li><a href="add_other_products.php">Add Accessories</a></li>
<li><a href="add_inventory.php">Add Inventory</a></li>
<li><a href="logout.php">Logout</a></li>
</ul> -->
<!--
<div class="dropdown">
  <button class="dropbtn">Dropdown</button>
  <div class="dropdown-content">
    <a href="add_specific_coffees.php">Add Video Games</a>
    <a href="add_other_products.php">Add Accessories</a>
    <a href="add_inventory.php">Add Inventory</a>
    <a href="logout.php">Logout</a>
  </div>
</div> -->
<!-- box begin -->
<div class="box">
	<div class="left-top-corner">
   	<div class="right-top-corner">
      	<div class="border-top"></div>
      </div>
   </div>
   <div class="border-left">
   	<div class="border-right">
      	<div class="inner">
         	<h3 align="center">About Cabelas 2.0 </h3>
         	<h5><p>This is the admin page</p></h5> 
         	<p>Cabelas 2.0 is better than the original! We have everything from hunting, camping and shooting gears to fit both yours and your family needs!</p>
         	<p>It's safe to shop here, unlike the bears attacking your tent. Promise!</p>
      </div>	
      </div>
   </div>
   <div class="left-bot-corner">
   	<div class="right-bot-corner">
      	<div class="border-bot"></div>
      </div>
   </div>
</div>
<!-- box end -->



<?php 
include('../includes/footer.html');

?>

